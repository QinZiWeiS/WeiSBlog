## <!-- _posts/2019-04-01-Promise.md -->

title: "JavaScript about Promise"
date: 2019-04-01
tags:

- Promise
- JavaScript

---

This is my first post.

The content above `more` is the excerpt, which will be displayed in the posts list.

<!-- more -->

The content below `more` will only be displayed when viewing this post, and will not be displayed in the posts list.
