---
layout: about
title: About
subtitle: You can be great but you don't have to be perfect
headerImage: /about-bg.jpg # picture in public directory
---

About personal Information...
